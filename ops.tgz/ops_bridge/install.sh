#!/usr/bin/env bash
# Bootstrap helper installation only. It does NOT register/start a runner or
# enable operations. Inspect/package/hash/review this exact directory first.
set -euo pipefail
[[ $# == 0 ]] || { echo 'FAIL: no arguments accepted'; exit 2; }
[[ $(id -u) == 0 ]] || { echo 'FAIL: trusted administrator bootstrap required'; exit 2; }
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[[ ! -e /opt/smartfinds-ops ]] || { echo 'FAIL: existing installation requires reviewed upgrade'; exit 2; }
for executable in python3 systemctl visudo install useradd getent; do
  command -v "$executable" >/dev/null || { echo 'FAIL: missing prerequisite'; exit 2; }
done
# Do not install on a pressured small host, silently resize it, or clean it.
python3 -I -B - <<'PY'
from pathlib import Path
import os
mem = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
available = int(mem['MemAvailable'].split()[0]) * 1024
s = os.statvfs('/')
if available < 512*1024**2 or s.f_bavail*s.f_frsize < 5*1024**3:
    raise SystemExit('FAIL: bootstrap resource headroom gate; no installation performed')
PY
[[ -d /root/pinterest-bot ]] || { echo 'FAIL: canonical production directory missing'; exit 2; }
visudo -cf "$package_dir/sudoers" >/dev/null
if getent passwd smartfinds-ops >/dev/null; then
  echo 'FAIL: pre-existing identity must be inspected; no privilege assumptions'
  exit 2
fi
useradd --system --user-group --home-dir /var/lib/smartfinds-ops/runner --shell /usr/sbin/nologin smartfinds-ops
install -d -o root -g smartfinds-ops -m 0750 /var/lib/smartfinds-ops /var/lib/smartfinds-ops/receipts
install -d -o smartfinds-ops -g smartfinds-ops -m 0700 /var/lib/smartfinds-ops/inbox /var/lib/smartfinds-ops/runner
install -d -o root -g root -m 0755 /opt/smartfinds-ops /opt/smartfinds-ops/releases
install -d -o root -g root -m 0700 /etc/smartfinds-ops
install -o root -g root -m 0644 "$package_dir/bridge.py" "$package_dir/client.py" /opt/smartfinds-ops/
install -o root -g root -m 0600 "$package_dir/policy.example.json" /etc/smartfinds-ops/policy.json
install -o root -g root -m 0644 "$package_dir/smartfinds-ops-request.service" /etc/systemd/system/smartfinds-ops-request.service
install -o root -g root -m 0440 "$package_dir/sudoers" /etc/sudoers.d/smartfinds-ops
visudo -cf /etc/sudoers.d/smartfinds-ops >/dev/null
systemctl daemon-reload
echo 'INSTALLED_DISABLED: no runner registered, no service started, no production proof'
