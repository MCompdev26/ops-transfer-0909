#!/usr/bin/python3
"""Fixed server-side operations worker. Stdlib only; never imports application code.

Installed root-owned at /opt/smartfinds-ops/bridge.py and started only by the
fixed systemd unit. It writes bridge receipts, never application state.
"""
from __future__ import annotations

import contextlib
import ast
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import stat
import subprocess
import time
from datetime import datetime, timezone

ROOT = Path('/root/pinterest-bot')
STATE = Path('/var/lib/smartfinds-ops')
POLICY = Path('/etc/smartfinds-ops/policy.json')
RELEASES = Path('/opt/smartfinds-ops/releases')
CANONICAL = 'https://smartfindlabapp.com/health'
LEGACY = 'https://smartfindslab.com/health'
READS = {'production_readonly_diagnostic', 'production_verify'}
DRY_RUN = 'deploy_reviewed_commit_dry_run'
MUTATIONS = {'deploy_reviewed_commit', 'restart_smartfinds_after_approved_deploy',
             'rollback_last_approved_deploy'}
OPERATIONS = READS | {DRY_RUN} | MUTATIONS
UNITS = ('smartfinds.service', 'nginx.service',
         'smartfinds-instagram-inventory-refill.service',
         'smartfinds-instagram-inventory-refill.timer',
         'smartfinds-instagram-scheduler.timer', 'smartfinds-pinterest.timer',
         'smartfinds-cleanup.service', 'smartfinds-cleanup.timer',
         'smartfinds-production-monitor.service', 'smartfinds-production-monitor.timer',
         'smartfinds-operational-backup.service', 'logrotate.service')
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'HOME': '/nonexistent'}
SHA = re.compile(r'[0-9a-f]{40}')


class Rejected(Exception):
    pass


class Deadline(Exception):
    pass


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def read_bytes(path, limit=1_048_576, *, owner=None):
    """No symlinks/FIFOs/devices, bounded read, optional root ownership check."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise Rejected('unsafe_file')
        if owner is not None and (info.st_uid != owner or info.st_mode & 0o022):
            raise Rejected('untrusted_file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise Rejected('oversized_file')
        return data
    finally:
        os.close(fd)


def read_json(path, limit=1_048_576, *, owner=None):
    return json.loads(read_bytes(path, limit, owner=owner))


def atomic_json(path, value):
    tmp = path.with_suffix('.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o640)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f, sort_keys=True, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    d = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(d)
    finally:
        os.close(d)


def validate_request(value, repository, epoch=None):
    expected = {'operation', 'run_id', 'source_commit', 'repository', 'created_at'}
    if not isinstance(value, dict) or set(value) != expected:
        raise Rejected('invalid_request_schema')
    if value['operation'] not in OPERATIONS:
        raise Rejected('operation_not_allowed')
    if value['repository'] != repository:
        raise Rejected('repository_mismatch')
    if not isinstance(value['run_id'], str) or not re.fullmatch(r'[1-9][0-9]{0,19}', value['run_id']):
        raise Rejected('invalid_run_id')
    if not isinstance(value['source_commit'], str) or not SHA.fullmatch(value['source_commit']):
        raise Rejected('invalid_commit')
    age = (time.time() if epoch is None else epoch) - value['created_at'] if type(value['created_at']) in (int, float) else math.inf
    if not math.isfinite(age) or not -30 <= age <= 600:
        raise Rejected('expired_request')
    return dict(value)


def run(argv, timeout=5, maximum=262144):
    """Fixed caller-owned argv only, no shell, bounded child lifetime/output."""
    with subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          env=ENV, start_new_session=True) as child:
        try:
            # All invoked utilities have bounded selected output; an oversized
            # result is never retained in a receipt.
            output, _ = child.communicate(timeout=timeout)
        except BaseException:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            raise
    if len(output) > maximum:
        raise Rejected('output_limit')
    if child.returncode:
        raise Rejected('command_failed')
    return output.decode('utf-8', errors='replace')


def age_seconds(timestamp):
    try:
        stamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        return (datetime.now(timezone.utc) - stamp).total_seconds()
    except (ValueError, TypeError, AttributeError):
        return None


def numbers(value, keys):
    return {k: value[k] for k in keys if type(value.get(k)) in (int, float, bool) and math.isfinite(value[k])}


def report(root, relative):
    data = read_json(root / relative)
    if not isinstance(data, dict):
        raise Rejected('invalid_report')
    return data


def units():
    properties = ('Id', 'ActiveState', 'SubState', 'Result', 'ExecMainStatus',
                  'NRestarts', 'MemoryCurrent', 'MemoryPeak', 'MemoryHigh', 'MemoryMax',
                  'ExecMainExitTimestamp', 'NextElapseUSecRealtime')
    output = run(['/usr/bin/systemctl', 'show', *UNITS,
                  *['--property=' + p for p in properties]])
    rows = {}
    for block in output.strip().split('\n\n'):
        fields = dict(line.split('=', 1) for line in block.splitlines() if '=' in line)
        unit = fields.pop('Id', '')
        if unit in UNITS:
            rows[unit] = {k: v for k, v in fields.items() if k in properties and len(v) <= 100}
    return rows


def memory_sample():
    mem = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        k, rest = line.split(':', 1)
        if k in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}:
            mem[k] = int(rest.split()[0]) * 1024
    vm = dict(line.split() for line in Path('/proc/vmstat').read_text().splitlines())
    mem.update({k: int(vm.get(k, 0)) for k in ('pswpin', 'pswpout')})
    pressure = Path('/proc/pressure/memory')
    if pressure.exists():
        for line in pressure.read_text().splitlines():
            kind, *fields = line.split()
            vals = dict(x.split('=') for x in fields)
            mem['psi_' + kind + '_avg10'] = float(vals['avg10'])
    events = Path('/sys/fs/cgroup/system.slice/smartfinds.service/memory.events')
    if events.exists():
        for line in events.read_text().splitlines():
            key, value = line.split()
            if key in {'high', 'oom', 'oom_kill'}:
                mem['service_' + key] = int(value)
    return mem


def classify_memory(first, second, service_bytes):
    total = second.get('MemTotal', 0)
    if not total or 'MemAvailable' not in second:
        return {'classification': 'UNKNOWN', 'current_host_pressure': None}
    ratio = second['MemAvailable'] / total
    deltas = {k: second[k] - first[k] for k in ('pswpin', 'pswpout', 'service_high', 'service_oom', 'service_oom_kill')
              if k in first and k in second and second[k] >= first[k]}
    pressured = ratio <= .15 or second.get('psi_full_avg10', 0) >= 1 or deltas.get('service_oom_kill', 0) > 0
    current_service = service_bytes / total
    return {'host_available_ratio': round(ratio, 4), 'service_ratio': round(current_service, 4),
            'current_host_pressure': pressured, 'critical': ratio <= .08 or current_service >= .75 or deltas.get('service_oom_kill', 0) > 0,
            'classification': 'CURRENT_PRESSURE' if pressured else 'SERVICE_THRESHOLD' if current_service >= .60
            else 'HISTORICAL_HIGH_COUNTER_ONLY' if second.get('service_high', 0) > 0 and deltas.get('service_high') == 0
            else 'NO_CURRENT_PRESSURE', 'counter_deltas': deltas,
            'counter_semantics': 'cumulative high counters alone do not prove present host pressure',
            'afternoon_event_cause': 'UNPROVEN_without_event_time_samples'}


def https(url):
    if url not in {CANONICAL, LEGACY}:
        raise Rejected('target_not_allowed')
    # No redirects, proxy environment, config files, cookies, credentials, or body.
    text = run(['/usr/bin/curl', '-q', '--noproxy', '*', '--silent', '--output', '/dev/null',
                '--connect-timeout', '2', '--max-time', '4', '--write-out',
                '%{http_code} %{time_total}', url], timeout=5, maximum=128)
    code, seconds = text.split()
    return {'status': int(code), 'seconds': float(seconds), 'healthy': code == '200'}


def probe_source_semantics(root):
    """Recognize the exact deployed monitor contract without reading .env.

    Reported target can prove effective configuration only when the inspected
    implementation demonstrably uses the same variable for request and report.
    Unknown source shapes fail closed rather than guessing from a hostname.
    """
    expected = '''
def public_health_snapshot() -> dict:
    url = os.getenv("SMARTFINDS_PUBLIC_HEALTH_URL", "https://smartfindslab.com/health")
    try:
        with urlopen(Request(url, headers={"User-Agent": "SmartFindsProductionMonitor/1.0"}), timeout=8) as response:
            status = int(response.status)
            return {"healthy": 200 <= status < 300, "status": status, "url": url}
    except HTTPError as error:
        return {"healthy": False, "status": int(error.code), "url": url}
    except (URLError, TimeoutError, OSError) as error:
        return {"healthy": False, "status": type(error).__name__, "url": url}
'''
    try:
        tree = ast.parse(read_bytes(root/'scripts/production_monitor.py'))
        matches = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'public_health_snapshot']
        same = len(matches) == 1 and ast.dump(matches[0], include_attributes=False) == ast.dump(ast.parse(expected).body[0], include_attributes=False)
    except (OSError, ValueError, SyntaxError):
        same = False
    return 'EFFECTIVE_REQUEST_TARGET_EQUALS_REPORT_METADATA' if same else 'UNRECOGNIZED_SOURCE_REQUIRES_REVIEW'


def readers():
    rows = []
    uptime = float(Path('/proc/uptime').read_text().split()[0])
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            comm = (p / 'comm').read_text().strip()
            argv = (p / 'cmdline').read_bytes().split(b'\0')
            candidate = comm == 'journalctl' or (comm.startswith('python') and argv[1:] in ([b'-', b''], [b'-u', b'-', b'']))
            if not candidate:
                continue
            fields = (p / 'stat').read_text().rsplit(')', 1)[1].split()
            age = uptime - int(fields[19]) / os.sysconf('SC_CLK_TCK')
            if age >= 120:
                rows.append({'kind': 'journal_reader' if comm == 'journalctl' else 'stdin_python_reader',
                             'age_seconds': round(age), 'cpu_ticks': int(fields[11]) + int(fields[12])})
        except (OSError, ValueError, IndexError):
            continue
    return {'stale_candidate_count': len(rows), 'candidates': rows[:20],
            'scope': 'old journalctl and Python stdin readers; no command lines or process identities exported'}


def storage(root):
    s = os.statvfs('/')
    total, used, free = s.f_blocks*s.f_frsize, (s.f_blocks-s.f_bfree)*s.f_frsize, s.f_bavail*s.f_frsize
    targets = {'application_backups': root/'backups', 'application_logs': root/'logs',
               'reports': root/'reports', 'generated_images': root/'export/generated_images',
               'videos': root/'exports/videos', 'system_logs': Path('/var/log'),
               'temporary': Path('/tmp'), 'system_cache': Path('/var/cache')}
    sizes = {}
    for label, path in targets.items():
        if not path.exists():
            sizes[label] = 0
            continue
        try:
            value = run(['/usr/bin/du', '-sx', '--block-size=1', '--', str(path)], timeout=2, maximum=4096)
            sizes[label] = int(value.split()[0])
        except (Rejected, subprocess.TimeoutExpired):
            sizes[label] = None
    files = {}
    for label, path in {'syslog': Path('/var/log/syslog'), 'syslog_previous': Path('/var/log/syslog.1'),
                        'catalog_database': root/'products.db', 'instagram_database': root/'logs/instagram_queue.sqlite3'}.items():
        try:
            files[label] = path.stat().st_size
        except OSError:
            files[label] = None
    return {'total_bytes': total, 'used_bytes': used, 'available_bytes': free,
            'used_percent': round(used/total*100, 2), 'warning_percent': 70,
            'high_percent': 80, 'critical_percent': 90, 'allocated_directory_bytes': sizes,
            'file_bytes': files, 'growth_rate': None, 'days_to_threshold': None,
            'forecast_status': 'NEEDS_comparable_time_separated_receipts'}


def collect(root=ROOT):
    unit = units()
    mon = report(root, 'reports/latest_production_monitor.json')
    pre = report(root, 'reports/latest_instagram_queue_preflight.json')
    queue = numbers(pre, ('future_valid_inventory', 'future_invalid_inventory', 'future_reserve_actual',
                         'future_reserve_required', 'posts_per_day', 'eligible_inventory_remaining'))
    queue.update({'report_age_seconds': age_seconds(pre.get('checked_at')), 'success': pre.get('success') is True,
                  'same_day_complete': pre.get('same_day_slot_coverage') == 'complete',
                  'safety_block_count': len(pre.get('safety_blocks') or [])})
    rate = queue.get('posts_per_day', 0)
    queue['runway_days'] = round(queue.get('future_valid_inventory', 0)/rate, 2) if rate else None
    a = memory_sample()
    time.sleep(1)
    b = memory_sample()
    service_memory = unit.get('smartfinds.service', {}).get('MemoryCurrent', '')
    memory = classify_memory(a, b, int(service_memory) if service_memory.isdigit() else 0)
    memory['samples'] = [a, b]
    memory['existing_monitor_summary'] = numbers(mon.get('memory') or {},
        ('warning', 'critical', 'host_available_bytes', 'host_available_ratio',
         'service_bytes', 'service_peak_bytes', 'cgroup_high_events', 'cgroup_oom_kills'))
    memory['monitor_warning_without_current_host_pressure'] = bool(
        memory['existing_monitor_summary'].get('warning') and memory['current_host_pressure'] is False)
    canonical = https(CANONICAL)
    try:
        legacy = https(LEGACY)
    except (Rejected, subprocess.TimeoutExpired):
        legacy = {'healthy': False, 'status': None}
    contract = report(root, 'config/production_access_contract.json')
    configured = (contract.get('application') or {}).get('health_url')
    reported = (mon.get('public_health') or {}).get('url')
    targets = {'canonical_contract_matches': configured == CANONICAL,
               'monitor_report_target': 'canonical' if reported == CANONICAL else 'legacy' if reported == LEGACY else 'unknown',
               'monitor_report_age_seconds': age_seconds(mon.get('checked_at')),
               'canonical': canonical, 'legacy_comparison': legacy,
               'discrepancy': 'NONE' if reported == CANONICAL else 'MONITOR_TARGET_CONTRACT_MISMATCH',
               'configuration_vs_metadata': probe_source_semantics(root)}
    # No environment file or raw monitor condition/message is exported.
    result = {'observed_at': now(), 'hostname_fingerprint': hashlib.sha256(socket.gethostname().encode()).hexdigest()[:16],
              'queue': queue, 'storage': storage(root), 'memory': memory, 'units': unit,
              'https': targets, 'remote_readers': readers(),
              'monitor': {'report_age_seconds': age_seconds(mon.get('checked_at')),
                          'critical_count': len(mon.get('active_critical_alerts') or []),
                          'queue_warning': 'instagram_queue_low' in (mon.get('active_warnings') or []),
                          'disk_warning': 'disk_warning' in (mon.get('active_warnings') or [])}}
    result['decision'] = decision(result)
    return result


def decision(evidence):
    q, d, m, h = (evidence[k] for k in ('queue', 'storage', 'memory', 'https'))
    reasons = []
    age = q.get('report_age_seconds')
    if age is None or not 0 <= age <= 5400 or not q.get('success'):
        reasons.append('queue_evidence_unavailable_or_stale')
    if (q.get('runway_days') or 0) < 7 or q.get('future_invalid_inventory') != 0 or not q.get('same_day_complete') or q.get('safety_block_count'):
        reasons.append('queue_runway_or_safety')
    if (q.get('future_reserve_actual') or 0) < (q.get('future_reserve_required') or 10):
        reasons.append('reserve_incomplete')
    if d.get('used_percent', 100) >= 80 or d.get('available_bytes', 0) < 5*1024**3:
        reasons.append('disk_headroom')
    if m.get('critical') or m.get('current_host_pressure') is not False:
        reasons.append('memory_pressure_requires_review')
    if h.get('canonical', {}).get('healthy') is not True or not h.get('canonical_contract_matches'):
        reasons.append('canonical_https_unhealthy_or_contract_invalid')
    if h.get('configuration_vs_metadata') != 'EFFECTIVE_REQUEST_TARGET_EQUALS_REPORT_METADATA':
        reasons.append('hostname_mapping_unverified')
    for name in ('smartfinds.service', 'nginx.service', 'smartfinds-instagram-inventory-refill.timer',
                 'smartfinds-instagram-scheduler.timer', 'smartfinds-pinterest.timer',
                 'smartfinds-cleanup.timer', 'smartfinds-production-monitor.timer'):
        if evidence['units'].get(name, {}).get('ActiveState') != 'active':
            reasons.append('required_unit_not_active')
            break
    for name in ('smartfinds-instagram-inventory-refill.service', 'smartfinds-cleanup.service',
                 'smartfinds-production-monitor.service', 'smartfinds-operational-backup.service', 'logrotate.service'):
        if evidence['units'].get(name, {}).get('Result') != 'success':
            reasons.append('required_observer_or_refill_failed')
            break
    mon = evidence['monitor']
    if mon.get('critical_count', 1) or mon.get('report_age_seconds') is None or not 0 <= mon['report_age_seconds'] <= 1800:
        reasons.append('monitor_critical_or_stale')
    if evidence['remote_readers'].get('stale_candidate_count', 1):
        reasons.append('stale_readers_need_attribution')
    return {'status': 'SAFE_TO_PROCEED_PRODUCT_PAGE_V2' if not reasons else 'VERIFICATION_REQUIRES_REVIEW',
            'reasons': sorted(set(reasons)), 'warning_only_is_blocker': False,
            'p0_p1_inference': 'operator must rank any failed prerequisites; unknown is not an incident'}


def trusted_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise Rejected('untrusted_directory')


def add_storage_comparison(evidence, prior):
    """Measured byte delta, not an invented sustained daily growth forecast."""
    old = prior.get('evidence', {})
    try:
        t1 = datetime.fromisoformat(old['observed_at'])
        t2 = datetime.fromisoformat(evidence['observed_at'])
        seconds = (t2-t1).total_seconds()
        old_disk, disk = old['storage'], evidence['storage']
        if seconds <= 0 or seconds > 7*86400 or old_disk['total_bytes'] != disk['total_bytes']:
            return
        disk['comparison_interval_seconds'] = seconds
        disk['used_bytes_change'] = disk['used_bytes'] - old_disk['used_bytes']
        disk['observed_bytes_per_day_equivalent'] = round(disk['used_bytes_change']*86400/seconds)
        disk['allocation_changes'] = {
            k: v-old_disk.get('allocated_directory_bytes', {}).get(k)
            for k, v in disk['allocated_directory_bytes'].items()
            if type(v) is int and type(old_disk.get('allocated_directory_bytes', {}).get(k)) is int}
        disk['forecast_status'] = 'OBSERVED_INTERVAL_ONLY_retention_and_workload_prevent_sustained_forecast'
    except (KeyError, TypeError, ValueError):
        return


def deployment_dry_run(commit, previous, releases=RELEASES):
    """Read/compare an admin-staged reviewed release; never runs release code."""
    if previous.get('operation') not in READS or previous.get('result') != 'success' or previous.get('verification', {}).get('status') != 'SAFE_TO_PROCEED_PRODUCT_PAGE_V2':
        raise Rejected('readonly_proof_required')
    age = age_seconds(previous.get('timestamp'))
    if age is None or not 0 <= age <= 1800:
        raise Rejected('readonly_proof_expired')
    release = releases / commit
    trusted_directory(releases)
    trusted_directory(release)
    approval = read_json(release/'approval.json', 65536, owner=0)
    if approval.get('source_commit') != commit or approval.get('reviewed') is not True or approval.get('tests_passed') is not True:
        raise Rejected('reviewed_commit_and_tests_required')
    if approval.get('production_mutation_allowed') is not False:
        raise Rejected('dry_run_only_approval_required')
    rows = approval.get('files')
    if not isinstance(rows, list) or not 1 <= len(rows) <= 100:
        raise Rejected('invalid_manifest')
    seen = set()
    for row in rows:
        if set(row) != {'path', 'sha256'} or not isinstance(row['path'], str):
            raise Rejected('invalid_manifest')
        p = Path(row['path'])
        if p.is_absolute() or not p.parts or any(not re.fullmatch(r'[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)*', x) for x in p.parts) or p.parts[0] not in {'public_site', 'seo_module', 'website_templates'} or p.suffix not in {'.py', '.css', '.html'} or str(p) in seen:
            raise Rejected('path_not_allowed')
        seen.add(str(p))
        for parent in list(p.parents)[:-1]:
            trusted_directory(release/parent)
        data = read_bytes(release/p, 2*1024**2, owner=0)
        if hashlib.sha256(data).hexdigest() != row['sha256']:
            raise Rejected('manifest_hash_mismatch')
        if p.suffix == '.py':
            compile(data, str(p), 'exec')  # compile only; never import/exec or pyc
    return {'status': 'dry_run_manifest_verified', 'files_checked': len(rows),
            'source_commit': commit, 'source_provenance': 'root_owned_admin_reviewed_commit_attestation',
            'tests': 'admin_attested_previous_tests_not_executed_as_root',
            'backup': 'planned_existing_operational_backup_no_backup_created',
            'transfer': 'not_performed', 'application_mutation': False,
            'existing_deploy_process_equivalence': 'NOT_YET_PROVEN_requires_live_gate'}


def execute(state=STATE, policy_path=POLICY, collector=collect, dry_runner=deployment_dry_run):
    trusted_directory(state)
    trusted_directory(state/'receipts')
    policy = read_json(policy_path, 4096, owner=0)
    if policy.get('enabled') is not True or policy.get('repository_private_verified') is not True:
        raise Rejected('installation_not_accepted')
    request = validate_request(read_json(state/'inbox/request.json', 4096), policy['repository'])
    digest = hashlib.sha256(json.dumps(request, sort_keys=True).encode()).hexdigest()
    path = state/'receipts'/('run-' + request['run_id'] + '.json')
    lock_fd = os.open(state/'operation.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(lock_fd, 'w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Rejected('operation_busy')
        if path.exists():
            old = read_json(path, owner=0)
            if old.get('request_digest') != digest:
                raise Rejected('duplicate_id_conflict')
            return old  # started-but-interrupted is not retried automatically
        files = list((state/'receipts').glob('run-*.json'))
        if len(files) >= 2000:
            raise Rejected('receipt_capacity_escalate_no_deletion')
        if files and time.time() - max(p.stat().st_mtime for p in files) < 60:
            raise Rejected('rate_limited')
        receipt = {'timestamp': now(), 'operation': request['operation'], 'request_digest': digest,
                   'source_commit': request['source_commit'], 'installed_worker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   'authority': 'bounded_readonly_bridge_v1', 'preflight': 'request_and_policy_valid',
                   'action': 'started', 'tests': 'not_applicable_readonly', 'verification': {}, 'result': 'started',
                   'rollback_status': 'not_applicable_no_application_mutation', 'sanitized_failure_reason': '',
                   'published': False, 'external_publishing_api_called': False, 'application_mutated': False}
        atomic_json(path, receipt)  # durable before any observation
        try:
            op = request['operation']
            if op in MUTATIONS:
                raise Rejected('mutation_disabled_readonly_proof_module')
            if op in READS:
                evidence = collector()
                try:
                    prior = read_json(state/'latest-readonly.json', owner=0)
                    add_storage_comparison(evidence, prior)
                except (OSError, ValueError, Rejected):
                    pass
                receipt.update(evidence=evidence, verification=evidence['decision'])
            else:
                proof = read_json(state/'latest-readonly.json', owner=0)
                receipt['verification'] = dry_runner(request['source_commit'], proof)
            receipt['result'] = 'success'
            receipt['action'] = 'read_only' if op in READS else 'dry_run'
        except Deadline:
            receipt.update(result='timeout', sanitized_failure_reason='operation_timeout')
        except Exception as exc:
            reason = str(exc) if isinstance(exc, Rejected) else type(exc).__name__
            receipt.update(result='failed', sanitized_failure_reason=reason if re.fullmatch(r'[a-zA-Z0-9_]{1,100}', reason) else 'operation_failed')
        receipt['finished_at'] = now()
        atomic_json(path, receipt)
        if request['operation'] in READS and receipt['result'] == 'success':
            atomic_json(state/'latest-readonly.json', receipt)
        return receipt


def main():
    if os.geteuid() != 0:
        print('{"result":"rejected","reason":"installed_worker_only"}')
        return 2
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(Deadline()))
    signal.alarm(75)
    try:
        receipt = execute()
        print(json.dumps({'result': receipt['result'], 'operation': receipt['operation']}))
        return 0 if receipt['result'] == 'success' else 1
    except Exception:
        # Unknown/invalid request content and underlying exception messages never
        # reach journals. No caller-provided string is printed.
        print('{"result":"rejected","reason":"request_or_worker_preflight_failed"}')
        return 2
    finally:
        signal.alarm(0)


if __name__ == '__main__':
    raise SystemExit(main())
