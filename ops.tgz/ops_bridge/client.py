#!/usr/bin/python3
"""Unprivileged fixed-protocol client; no checkout or caller-supplied commands."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import time

STATE = Path('/var/lib/smartfinds-ops')
OPS = ('production_readonly_diagnostic', 'production_verify', 'deploy_reviewed_commit_dry_run')


def invoke(operation, run_id, commit, repository, state=STATE):
    if operation not in OPS or not re.fullmatch(r'[1-9][0-9]{0,19}', run_id) or not re.fullmatch(r'[0-9a-f]{40}', commit) or not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
        raise ValueError('invalid_request')
    with (state/'inbox/client.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result = state/'receipts'/('run-' + run_id + '.json')
        # Retry/reconnect reads the immutable prior receipt; it does not submit.
        if result.exists():
            receipt = json.loads(result.read_text())
            if receipt.get('operation') != operation or receipt.get('source_commit') != commit:
                raise ValueError('duplicate_id_conflict')
            return receipt
        request = {'operation': operation, 'run_id': run_id, 'source_commit': commit,
                   'repository': repository, 'created_at': time.time()}
        temp = state/'inbox/request.tmp'
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as f:
            json.dump(request, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, state/'inbox/request.json')
        # This is the only sudo capability. Root systemd runs a fixed installed
        # worker; neither arguments, environment nor repo code reach that unit.
        try:
            child = subprocess.run(['/usr/bin/sudo', '-n', '/usr/bin/timeout', '-k', '2s', '5s',
                                    '/usr/bin/systemctl', 'start', '--no-block', 'smartfinds-ops-request.service'],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, timeout=10,
                                   env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'HOME': '/nonexistent'})
        except subprocess.TimeoutExpired:
            raise RuntimeError('activation_timeout_service_watchdog_remains_authoritative') from None
        if child.returncode:
            raise RuntimeError('no_matching_receipt_activation_or_preflight_failed')
        deadline = time.monotonic() + 90
        while True:
            receipt = json.loads(result.read_text()) if result.exists() else None
            if receipt and receipt.get('result') != 'started':
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('receipt_timeout_service_watchdog_remains_authoritative')
            time.sleep(.5)
        if receipt.get('operation') != operation or receipt.get('source_commit') != commit:
            raise RuntimeError('receipt_identity_mismatch')
        return receipt


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--operation', choices=OPS, required=True)
    p.add_argument('--run-id', required=True)
    p.add_argument('--commit', required=True)
    p.add_argument('--repository', required=True)
    a = p.parse_args()
    try:
        receipt = invoke(a.operation, a.run_id, a.commit, a.repository)
        print(json.dumps(receipt, sort_keys=True))
        return 0 if receipt.get('result') == 'success' else 1
    except Exception:
        print('{"result":"failed","reason":"bridge_activation_or_receipt_failed"}')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
